
---------------------------------------------------------------
 PLEASE READ THIS UNLESS YOU WANT TO FRY EGGS ON YOUR THINKPAD 
---------------------------------------------------------------


-------------------------------
 License/Use:
-------------------------------

This program and source code is in the public domain.

The author claims no copyright, copyleft, license or
whatsoever for the program with exception of WinIO driver.  
You may use, reuse, abuse or distribute it's binaries 
or source code in any desired way or form, Usage of 
binaries or source shall be entirely and without 
exception at your own risk. 

Usage of WinIO is excempt from this license. The WinIO
driver is (C) by Yariv Kaplan at www.internals.com.  
License terms for WinIO can be found at 
http://www.internals.com/utilities_main.htm



-------------------------------
 Introduction:
-------------------------------

This is a early experimental fan control program for the
Thinkpad T43 and other models.  It has mainly been tested 
on my own machine (Model. 2668-97G).  It may or may not 
work on other series Thinkpads.  Some have been already
been tested with success (see below), which may or may
not allow conclusions about usage on your computer.


THIS PROGRAM IS VERY EXPERIMENTAL.  NO WARRANTY IS GIVEN 
WHATSOEVER.  USE OF THE PROGRAM IS ENTIRELY AND WITHOUT
EXCEPTION YOUR OWN RISK.

If you even think about blaming the author for problems
caused by the program, then just don't use it (instead 
ask IBM to fix their d*mn fan.)  If you are not sure if 
you want to try, just read this carefully and think again.  
If you are sure that you want to try it still read this
file. And please share your results (see links below).

Have you realy read the above?  Do you get the picture?

Well, good!



-------------------------------
 Further Warnings:
-------------------------------

There are possible caveats with this program, some may 
even appyl after successfully having it tested for a 
few days or even weeks:

- In active mode the program writes to a location in 
  the embedded controller area.  Doing this on a system
  where the byte at this location has another meaning 
  may do all kinds of unexpected and possibly serious 
  things to computers where the specific location in 
  the EC has a different meaning. 

- Interfering with ACPI software: ACPI aware software
  (including Windows XP, Thinkpad tools, Thinkpad drivers) 
  communicates with the EC. Running TP43 Fan Control may 
  interfere with these functions with unpredictable results.

- When the program controls the fan speed and crashes 
  it will obviously no longer be able to do so.  If at
  the time of the crash the fan was off, it will remain
  so, independent of the system temperature.

- Probably other nasty and undesireable things.



-------------------------------
 Tested Models:
-------------------------------

Currently users have reported successful initial tests 
with the following Thinkpad  machines. (Great thanks to 
those who were brave enough try):

- Series (Model)
- T23 (2647)
- T40 (2373)
- T41p (2373), 
- T42 (2373)
- T43 (1871 and 2668)
- T43p (2668)
- A31p (2653)
- R50 (1829)
- R50e (1834)
- X41 (tablet 1866)

There are no guarantees but this indicates that 
trying it on T4X models may not run the risk of 
immediate disastrous results.

Other Thinkpad Series (R, A, X, Z, etc.) may also
work.

A test on an X20 indicated that the program does 
not work on this model.



-------------------------------
 Links:
-------------------------------

Downloads:
- http://sourceforge.net/project/showfiles.php?group_id=153962


Support Thread for this tool:
- http://forum.thinkpads.com/viewtopic.php?t=17715


Thread for sharing/comparing temperature results
- http://forum.thinkpads.com/viewtopic.php?t=17733


Tech Background:
- http://www.thinkwiki.org/wiki/Patch_for_controlling_fan_speed
- http://www.thinkwiki.org/wiki/Talk:Problem_with_fan_noise
- http://www.thinkwiki.org/wiki/Talk:ACPI_fan_control_script


WinIO Driver:
- http://www.internals.com/utilities/utilities.htm




-------------------------------
 Purpose/Implementation:
-------------------------------

The program reads the fan control register and various 
temperature sensors. In active mode it allows to manually
change the fan control register and it is able to 
dynamically switch the fan speed depending on the 
temperature readings.

Fan control is implemented by directly communicating with
the embedded controller (EC) via port numbers 0x62 and 
0x66 by means of a Windows driver (WinIO, see link above).




-------------------------------
Installation:
-------------------------------

Unpack the ZIP file to a folder anywhere on your *local*
hard drive. After that you should have the following files 
there:

fancontrol.exe
fancontrol.ini
readme.txt
WinIo.dll
WinIo.sys

(WinIO is a third party driver.  Please see the links and 
license sections for more).



-------------------------------
 Test "Compatibilty":
-------------------------------

So, you really did read the disclaimer above and still want to
try?  Please read the test instructions fully before you start
the program.

Open the folder where you unpacked the ZIP file.  Edit the 
fancontrol.ini file (right click, open with, Notepad). Make 
sure that the "active" switch is set to zero and save the file.  

With this setting the program will only read values from the 
Thinkpad but will not make any modifications.  It is still 
possible that this mode will will interfere with other programs, 
but there is no high probability of permanent damage.  If there
are problems, a reboot should cure the situation. 

Then close all programs which may do things to your CPU or
BIOS.  Mainly under/overvlocking, under/overvolting, temperature
and speed monitoring applications.  I'm speaking of tools
like "Notebook Hardware Control", etc. The reason for this is
that these program are also reading from the EC and there is 
currenty no known way to synchronize EC access between programs.


Now, hold your breath and double click the FanControl.exe icon.

This should give you a window named "Thinkpad T43 Fan Control".
If you get an error message about the WINIO Driver, make sure
that all files are in your folder and that it resides on your
local hard drive (not on a network).  You also need to be logged
on with administrative privileges.  

I have no experience with that driver yet, so if you keep getting 
this message you'll probably need to experiment or check with the 
WINIO developer (http://www.internals.com/utilities/utilities.htm).

Assuming that you did get the "Thinkpad T43 Fan Control" 
window, you'll need to check the follwing fields to see 
if they show meaningful values.


Check 1: "Fan State"
What you want to see in the first field is either:
"0x80 (BIOS Controlled)" or "0x0Y (Fan Level Y, Non Bios)"
with a value of 0-7 for "Y".  The first value (0x80) is 
preferrable.

Check 2: "Temp."
In the second field you should find something like 
"Highest 47�C" and 

  CPU 41�C (0x78)
  APS 38�C (0x79) 
  X7A 31�C (0x7A) 
  GPU 40�C (0x7B)
  BAT 32�C (0x7C) 
  BAT 30�C (0x7E) 
  XC0 36�C (0xC0) 
  PCI 43�C (0xC1) 
  PWR 41�C (0xC2)  


There should be a series of values with realistic temperatures
(in Celcius).  For people from the Farenheit realm values from
25�C to 60�C are realistic (20�C is room temperature, 37�C is 
human body temperature, 60�C is quite hot to the touch, 100�C 
is boiling water).  The meaning of the sensors is described 
further below.

If you have a program which monitors the CPU temp. start it 
later (remember, such stuff should not be running on your first 
test) and check if the CPU value in brackets matches the tool's 
CPU temperature display.

Check 3: "Status"
The list below the status field shoud show a configuration
(Active= 0, Cycle= 5) and some levels.  If you scroll down 
there should be no further messages, especially none saying
"Can't read status!" (this error indicates problems reading
from the EC, reason could be collision with other software
which reads the embedded controller at the same time).

If you have problems here, do not continue.  Please report
them on the forum instead and I'll see what I can do.




-------------------------------
 Test "Active Run":
-------------------------------

Remember, this program is very early and has only been tested
on a few machines. It may do funny things to other models and 
may have bugs.  So have a fire extinguisher at hand or a fresh 
egg (the Thinkpad may turn into the most expensive pan �n your 
house).

Okay, I see you'res serious.  Well, edit the fancontrol.ini
file, change the "active" setting to 1 and save.  Start  
FanControl.exe again.  Now the same window should appear with the
same realistic values (see above), but the buttons for "Mode" 
should be enabled and the one for BIOS should be selected.

For a test switch mode to "Manual" and change the value between
0 and 7 (only type these digits, no spaces or other characters).
You should hear a quick beep and see a message in the field
at the bottom of the window which hopefully will say "RESULT: OK!"
After a few seconds (up to 5) you should hear the fan change
it's speed.  If you turn it off (value "0") the fan may in 
fact accellerate for a moment before going off.



-------------------------------
 Test "Exit from Active":
-------------------------------

When exiting the program should switch the fan control back 
to BIOS.  To check if this works, turn the fan off (manual
mode, value 0) and exit the program.  You should hear a short
beep and then the fan should come up again.  (The fan may stay
off if your system is cold, so try with a well heated state.
The idea here is to test if the progam swtiches the fan back
to BIOS controlled mode.)

*** WARNING!  If the program crashes while the fan is off 
*** it will not be able to switch the fan back to BIOS mode.  
*** This will leave the fan locked in it's current state 
*** (which may be off).
*** This could seriously harm your computer. If the program 
*** crashes either try to start it and then exit or reboot 
*** your machine.




-------------------------------
 Smart Mode
-------------------------------

Smart mode is quite straightforward.  The program takes the 
highest temperature value and compares it to the table in the
fancontrol.ini file.  The fan speed will be triggered up 
as soon as a value is reached.  To fall back the temperature
must fall back to the previous value.  E.g. on the default 
table the fan will go on at 50�C but will only go off it the
value drops to 48�C or below.

*** WARNING!  The values in the should be ascending and 
*** meaningful. Anything else than ascending (e.g. switching
*** fan off at 80�C) will have unpredictable results
*** (among which may be blisters and fried eggs).

The values in the table can be edited in the fancontrol.ini
file.  You can have more or less steps there.  The first 
level should be associated with a fan level of zero, the
temperature there is the switch-off temperature (fan will
go off if system cools down below that point).

Also, one user idicated, that possibly fan speed 
1/2 and 3/4/5 and 6/7 are equivalent to each other.

Also on T40/R50 machines users reported that there were only
fan levels of 0/1/2(?)/3





-------------------------------
 Temperature Sensors:
-------------------------------

The first temperature value seems to be the CPU.  The meaning 
of some other sensors is currently unknnown.  If someone wants
to open his machine and treat it with some cooling spray, please
let me know.

Here's what's currently known (or more accurately the result
of experminetation and some creative guessing on
http://www.thinkwiki.org/wiki/Talk:Problem_with_fan_noise)

  CPU: quite definitely the CPU

  APS: temperature sensor between CPU and PCMCIA slots
       (below left Alt key) (T43 2668)

  PCM: below PCMCIA slot (front/left)

  GPU: graphical processor

  BAT: battery (inside, front/left of battery in a T43)

  BAT: battery (inside, rear/right of battery in a T43)

  BUS: between Northbridge and DRAM (below R/T/Y keys)

  PCI: Southbridge chip below the touchpad (reacts to 
       WLAN usage, located under WLAN mini PCI card)

  PWR: power supply, somewhere below the Acess-IBM button.
       (heats when charging the battery)




-------------------------------
 EC Port/Other Programs:
-------------------------------

I have had problems running Fan Control with other similar 
programs.  Mainly with NHC (Notebook Hardware Control). There
seem to be conflicts when reading the EC (Embedded Controller)
registers.  So far my only solution is to turn these programs
off.  





-------------------------------
 Versions:
-------------------------------

V0.10 - 2005-11-27
 - first release 


V0.11 - 2005-11-28
 - display temperature with their (known) meanings
 - display fan mode on change commands in hex
 - display stats in minimized window title
 - option to change/disable beep
 - some GUI changes

V0.12 - 2005-11-29
 - RPM fan speed display
 - allow smart mode to automatically switch to bios
   mode at certain temperature

V0.13 - 2005-11-29
 - more detailed log display
 - log display limited to 100 lines
 - write logfile (fancontrol.log)


V0.14 - 2005-11-30
 - taskbaricon (see fancontrol.ini)
 - allows to start in smart mode (see "active" in
   fancontrol.ini)

V0.15 - 2005-11-30
 - IconLeves could not be read from ini
 - option to start minimized
 - option to ignore sensors in max. temp evaluation
 - function to exit after max allowed read errors 

V0.16 - 2005-12-04
 - prevent sluggishness in window handling
 - allow to switch back from 0x80/128 in smart mode
 - option that close button minimzes window instead

V0.17 - 2005-12-05
 - program was broken (internal lockup)

V0.18 - 2005-12-08
 - another possible bug fixed (buffer overrun, crash)
 - sensors now all named
 - included picture with T43 sensor locations
 - included German readme file
 - fancontrol.ini sample has German descriptions also



-------------------------------
 Ideas:
-------------------------------


- Run as service
- Take care of the pulsing fan problem.
- Different threshold for CPU/GPU



-------------------------------
 Hall of Fame:
-------------------------------

Thanks to

- Thinkerer from the www.thinkpads.com forum 
  for providing a lot of insight regarding the 
  temperature sensors

- Sebume from the www.thinkpad-forum.de 
  for providing the German translation of the 
  readme file.

- mANoLo27 from the www.thinkpad-forum.de forum
  for German translations of the fancontrol.ini
  comments