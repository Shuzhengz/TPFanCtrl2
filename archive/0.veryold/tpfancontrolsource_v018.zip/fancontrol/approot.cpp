
// --------------------------------------------------------------
//
//  Thinkpad Fan Control
//
// --------------------------------------------------------------
//
//	This program and source code is in the public domain.
//
//	The author claims no copyright, copyleft, license or
//	whatsoever for the program itself (with exception of
//	WinIO driver).  You may use, reuse or distribute it's 
//	binaries or source code in any desired way or form,  
//	Useage of binaries or source shall be entirely and 
//	without exception at your own risk. 
// 
// --------------------------------------------------------------

#include "fancontrol.h"
#include "winio.h"


HINSTANCE hInstApp, 
		  hInstRes;


//-------------------------------------------------------------------------
//  
//-------------------------------------------------------------------------
int APIENTRY
WinMain(HINSTANCE instance, HINSTANCE , LPSTR parm, int )
{
	DWORD rc= 0;
	char curdir[256]= "";

	hInstRes= instance;
	hInstApp= instance;


	::InitCommonControls();

	//
	// change down from DevStudio development folders
	//
	::GetCurrentDirectory(sizeof(curdir), curdir);
	if (stricmp(curdir+strlen(curdir)-6, "\\Debug")==0) {
		curdir[strlen(curdir)-6]= '\0';
		::SetCurrentDirectory(curdir);
	}

	if (stricmp(curdir+strlen(curdir)-8, "\\Release")==0) {
		curdir[strlen(curdir)-8]= '\0';
		::SetCurrentDirectory(curdir);
	}


	// 
	// Get going ...
	//
	if (InitializeWinIo()) {	// WINIO driver (http://www.internals.com/utilities/utilities.htm)

		verbosity= 0;
		strcpy(logbuf, "");

		FANCONTROL fc(instance);

		fc.Test();

		fc.ProcessDialog();

		ShutdownWinIo();
		rc= 0;
	}
	else {
		::MessageBox(HWND_DESKTOP, 
					"Error during initialization of WinIo Driver.\r\n"
					"(winio.sys missing in app folder or failed to load)",
					"Fan Control", 
					MB_ICONERROR | MB_OK | MB_SETFOREGROUND);

		rc= 1;
	}

	return (rc);
}
