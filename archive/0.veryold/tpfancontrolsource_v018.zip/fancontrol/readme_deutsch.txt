
----------------------------------------------------------------
BITTE LESEN SIE DIESES README SORGF�LTIG UM SCHADEN ZU VERMEIDEN
----------------------------------------------------------------


-------------------------------
 Lizenz / Gebrauch:
-------------------------------

Dieses Programm und der Quelltext sind gemeinfrei.


Der Autor beansprucht f�r das Programm kein Urheberrecht,
keine Lizenz oder �hnliches mit Ausnahme des WinIO-Treibers.
Sie k�nnen dieses Programm oder dessen Quelltext in jeder 
gew�nschten Form nutzen oder weiterverwerten. Der Gebrauch 
der Bin�rdateien oder des Quelltextes erfolgt vollst�ndig und 
ausnahmelos auf eigene Gefahr. 

Der Gebrauch des WinIO-Treibers ist von dieser Bestimmung 
ausgenommen.Das Urheberrecht des WinIO-Treibers liegt bei Yariv 
Kaplan (http://www.internals.com). Die dazugeh�rigen 
Lizenzbestimmungen f�r WinIO k�nnen hier eingesehen werden: 
http://www.internals.com/utilities_main.htm


-------------------------------------------
 Einf�hrung
-------------------------------------------

Diese Software ist eine fr�he Version eines experimentellen 
Programmes zur L�ftersteuerung des IBM Thinkpad T43. Es 
wurde vom Autor nur auf einem T43 (2668-97G) umfassend 
getestet. Es kann auch mit anderen Modellen funktionieren, 
Sie finden die Liste der erfolgreich getesten Modelle weiter
unten in dieser Datei. Entscheiden Sie hieraus auf eigene 
Verantwortung, ob Sie das Programm auf Ihrem Rechner einsetzen
wollen. 


DIESES PROGRAMM IST EXPERIMENTELL. DER AUTOR GIBT KEINE GARANTIE
F�R DIE FUNKTIONSF�HIGKEIT UND UNBEDENKLICHKEIT. SIE BENUTZEN DAS 
PROGRAMM IN JEDER HINSICHT AUF EIGENES RISIKO!

Falls Sie es auch nur entfernt in Erw�gung ziehen den Autor f�r 
eventuelle Probleme, die das Programm verursachen k�nnte, zur 
Verantwortung zu ziehen benutzen Sie es bitte nicht! (Bringen Sie 
IBM dazu, das Problem des L�fterdauerlaufes selbst zu l�sen!). 

Wenn Sie sich nicht sicher sind, ob Sie es wirklich ausprobieren 
wollen, lesen Sie dieses README aufmerksam und denken Sie gut dar�ber 
nach. Wenn Sie es dann immer noch probieren wollen, beachten Sie 
alle Hinweise in diesem README und berichten Sie bitte, ob es bei 
Ihnen funktioniert hat. 

Sie haben alles verstanden, was bis hier geschrieben steht? 
Wirklich alles? 

Fein! 


-------------------------------------
 Weitere wichtige Hinweise:
-------------------------------------

- Im "Active"-Modus schreibt das Programm in einen Bereich des 
  Embedded Controllers (EC). Passiert das auf einem System, in dem 
  der entsprechende Bereich eine andere Bedeutung hat, sind alle, 
  m�glicherweise ernsten Folgen, f�r diese Systeme denkbar.

- Konflikte mit ACPI-Programmen: Software, die auf das ACPI zugreift 
  (auch Windows XP, Thinkpad-Tools und -Treiber) kommuniziert mit dem 
  EC.  Der Betrieb von TP43 Fan Control kann diesen Prozess mit 
  unvorhersagbaren Folgen beinflussen.

- Kontrolliert TP43 Fan Control den L�fter (smart-mode) und st�rzt 
  w�hrenddessen ab, kann es den L�fter logischerweise nicht mehr steuern. 
  Sollte der L�fter zum Zeitpunkt des Absturzes aus sein, wird er es 
  unab�ngig von der Systemtemperatur auch bleiben.

- Dar�berhinaus k�nnen auch alle m�glichen anderen ungewollten und 
  unerw�nschten Dinge passieren.


---------------------------------------
 Getestete Modelle:
---------------------------------------

Bisher haben Nutzer von TP43 Fan Control �ber erste erfolgreiche Tests 
mit den folgenden Thinkpads berichtet (Danke f�r den Mut der Tester):

- Serie (Modell)
- T23 (2647)
- T41p (2373), 
- T42
- T43 (1871 and 2668)
- T43p (2668)
- R50 (1829)
- R50e (1834)
- X41 (tablet 1866)  


Das k�nnte als Hinweis ausgefasst werden, dass das Programm auch mit 
anderen T4x Modellen funktioniert, ohne sofort heftige Probleme zu 
verursachen.

Mit anderen Thinkpad Typen (R, A, X, Z, etc) k�nnte es ebenfalls 
funktionieren.

Ein Test mit einem X20 schlug fehl.



-----------------------------------------
 Weiterf�hrende Links:
-----------------------------------------

Deutscher Support-Thread f�r das Programm:
- http://thinkpad-forum.de/forum/viewtopic.php?t=3290

Englischer Support-Thread f�r das Programm:
- http://forum.thinkpads.com/viewtopic.php?t=17715

Thread zum Austauschen von Limits und Einstellungen (englisch)
- http://forum.thinkpads.com/viewtopic.php?t=17733

Techischer Hintergrund (englisch):
- http://www.thinkwiki.org/wiki/Patch_for_controlling_fan_speed
- http://www.thinkwiki.org/wiki/Talk:Problem_with_fan_noise
- http://www.thinkwiki.org/wiki/Talk:ACPI_fan_control_script

WinIO Driver (englisch):
- http://www.internals.com/utilities/utilities.htm




-------------------------------
 Zweck und Funktionsweise:
-------------------------------

Dieses Programm liest die L�ftersteuerungs-Register und verschiedene 
Temperatursensoren aus. Im "active-mode" k�nnen mit seiner Hilfe die 
entsprechenden Register des EC ge�ndert und dadurch die L�ftergeschwindigkeit 
in Abh�ngigkeit der ermittelten Temperatur ver�ndert werden.

TP43 Fan Control erreicht dies durch direkte Kommunikation mit dem Embedde 
Controller des Thinkpads auf den Port-Nummern 0x62 und 0x66 mit Hilfe 
eines Windows-Treibers (WinIO)



-------------------------------
 Installation:
-------------------------------

Entpacken Sie die Zip-Datei in einen Ordner Ihrer Wahl auf einer lokalen(!) 
Festplatte.Danach sollten folgende Dateien dort vorhanden sein:

fancontrol.exe
WinIo.dll
WinIo.sys
fancontrol.ini
readme.txt (diese Datei)


-------------------------------
 Kompatibilit�tstest:
-------------------------------

Wenn Sie dieses Programm nach der Lekt�re bis hierher immer noch ausprobieren, 
lesen Sie die folgenden Test-Anweisungen vollst�ndig, bevor Sie das Programm 
starten.


Offnen Sie den Ordner mit dem Programm und �ffnen Sie die fancontrol.ini 
(Rechtsklick, �ffnen mit, Notepad). Stellen Sie sicher, dass dort "active=0" 
eingetragen ist und speichern Sie die Datei.

(Mit dieser Einstellung wird das Programm nur Werte auslesen, aber keine 
Ver�nderungen im EC vornehmen. Es ist immer noch m�glich, dass diese 
Einstellung mit anderen Programmen kollidiert, dauerhafte Besch�digung ist 
jedoch unwahrscheinlich. Bei Problemen sollte ein Neustart des Computers helfen.)

Danach schlie�en Sie alle Programme, die evtl. auf das Bios oder die CPU einwirken 
(vor allem Unter/�bertaktungs-Programme, Temperatur- und Geschwindigkeits-Messer 
wie z.B. Notebook Hardware Control). Der Grund hierf�r liegt darin, dass diese 
Programme ebenfalls aus dem EC lesen und bisher noch kein Weg bekannt ist, den 
Zugriff auf den EC zu synchronisieren. 

Nun starten Sie fancontrol.exe.

Es sollte sich ein Fenster �ffnen, in dessen Titelleiste "Thinkpad Fan Control" 
steht. Erhalten Sie eine Fehlermeldung bez�glich des WINIO-Treibers, stellen Sie 
sicher, dass alle Dateien im Ordner vorhanden sind und er sich auf einer lokalen 
Festplatte und nicht im Netzwerk befindet! Der Treiber stammt nicht vom Autor 
dieses Programmes, daher sind auch andere Gr�nde m�glich (siehe dazu 
http://www.internals.com/utilities/utilities.htm).

Erhalten Sie das genannte Fenster, �berpr�fen Sie folgende Felder, ob Sie sinnvolle 
Werte anzeigen:

Check 1: "Fan State"
  Entweder sehen sie dort "0x80 (BIOS Controlled)" oder "0x0Y (Fan Level Y, 
  Non Bios)"   wobei das "Y" einen Wert zwischen 0 und 7 hat.  Der erste Wert 
  ist (0x80) zu bevorzugen.

Check 2: "Temp."
  Im zweiten Feld sollten Sie etwas wie "Highest 47�C" und 

   CPU 41�C (0x78)
   APS 38�C (0x79)  
   PCM 31�C (0x7A)  
   GPU 40�C (0x7B)  
   BAT 32�C (0x7C)  
   BAT 30�C (0x7E)  
   XC0 36�C (0xC0)  
   PCI 43�C (0xC1)  
   PWR 41�C (0xC2)  

  �hnlich dieses Beispieles sollten in diesem Feld eine Reihe realistischer
  Temperaturen (in Celsius) angezeigt werden. Werte von 25� bis 60� k�nnen
  als realistisch angesehen werden. Die Bedeutung der Sensoren ist weiter 
  unten erkl�rt.

  Verf�gen Sie �ber Programme, die die CPU-Temperatur anzeigen, k�nnen Sie mir 
  ihrer Hilfe �berpr�fen, ob TP43 Fan Control richtige Werte liefert (Beenden Sie 
  daf�r das Programm und denken Sie daran, es w�hrend des Tests nicht parallel zu 
  anderen ACPI-Programmen laufen zu lassen).

Check 3: "Status"
  Die Liste unter dem Status-Feld soll die Konfiguration (Active=0, Cycle=5) 
  und einige Werte zeigen. Wenn Sie herunterscrollen, sollten dort keine weiteren 
  Nachrichten angezeigt werden,vor allem nicht "Can't read status!" (Dieser Fehler 
  weist darauf hin, dass TP43 Fan Control nicht aus dem EC lesen kann, z.B. durch 
  Konflikte mit anderer software).

Sollten bei einem dieser Checks Probleme auftauchen, fahren Sie nicht fort. Melden 
Sie den Fehler in einem Support-Forum es wird gemeinsam eine L�sung gesucht. 


-------------------------------
 Betriebstest:
-------------------------------

Bedenken Sie, dass es sich bei diesem Programm nur auf wenigen Ger�ten getestet 
wurde. Auf anderen Ger�ten kann es zu Fehlern f�hren und nicht zuverl�ssig 
funktionieren. Ein Feuerl�scher und ein rohes Ei zum Test der neuen Funktion als 
Bratpfanne sollten immer zur Hand sein ;)

Sie ziehen es immer noch ernsthaft in Erw�gung? Ok, �ffnen Sie wieder die 
fancontrol.ini, �ndern Sie die "active"-Option auf active=1 und speichern Sie. 
Starten Sie die FanControl.exe wieder. Nun sollte das gleiche Fenster mit 
sinnvollen Daten erscheinen wie im Testlauf. Im Unterschied sollten jetzt die 
Schalter f�r "Mode" aktiviert sein und auf "Bios" stehen.

F�r einen Test schalten Sie den "Mode" auf "Manual" und �ndern Sie den Wert 
zwischen 0 und 7 (verwenden Sie nur diese Zahlen, keine Leerzeichen und keine 
Buchstaben). Sie sollten ein kurzes Piepen h�ren und eine Meldung "Result: OK" 
sollte im unteren Feld erscheinen. Nach bis zu 5 Sekunden sollten Sie h�ren, 
wie der L�fter seine Geschwindigkeit �ndert. Schalten Sie den L�fter aus, 
k�nnte der L�fter f�r einen kurzen Moment beschleunigen, bevor er verstummt.



---------------------------------------------------
 Betriebstest - R�ckgabe der Kontrolle ans Bios:
---------------------------------------------------

Sobald Sie das Programm beenden, sollte die L�ftersteuerund ans BIOS 
zur�ckgegeben werden.Um zu probieren, ob das funktioniert, schalten Sie den 
L�fter aus (Manual-Mode, Wert 0) und beenden Sie das Programm. Sie sollten 
ein kurzes Piepen h�ren und der L�fter wieder starten (Sollte Ihr System 
noch zu k�hl sein, kann der L�fter auch ausbleiben, probieren Sie es also 
in einem Temperatur-Bereich, in dem der L�fter normalerweise bereits l�uft).

*** WARNUNG!  Sollte das Programm abst�rzen, w�hrend der L�fter ausgeschaltet 
*** ist, kann es die L�ftersteuerung nicht zur�ck ans BIOS �bergeben. 
*** Der L�fter w�rde dann im zuletzt gew�hlten Status verbleiben (z.B. aus).
*** Dadurch kann Ihr Rechner ernsthaft besch�digt werden. Sollte das Programm 
*** abst�rzen, versuchen Sie, es erneut zu starten oder starten Sie Ihren 
*** Computer neu. 



---------------------------------------------------
 Betriebstest - Smart Mode:
---------------------------------------------------

Der "Smart Mode" entfaltet die volle Funktion des Programmes. Das Programm nimmt 
den h�chsten Wert der Temperatursensoren und vergleicht ihn mit den Werten in der 
fancontrol.ini (Level). Wird einer der Werte erreicht, wird die entsprechende 
L�ftergeschwindigkeit ausgel�st. Wird der n�chstniedrigste Wert erreicht, wird 
die L�ftergeschwindigkeit gesenkt. Z.B. in der Beispielkonfiguration wird der 
L�fter bei 50� eingeschaltet und bei 48� oder darunter wieder ausgeschaltet. 

*** ACHTUNG!  Die Level in der fancontrol.ini sollten aufsteigend und sinnvoll 
*** sein. Alles andere, z.B. den L�fter bei 80� auszuschalten, wird unvorhersagbare 
*** Ergebnisse haben (im schlimmsten Fall wird Ihr Ger�t besch�digt).

Die verschiedenen Level k�nnen in der fancontrol.ini bearbeitet werden. Sie k�nnen 
beliebig viele Level definieren. Der erste Level sollte mit einer 
L�ftergeschwindigkeit von 0 belegt sein, die Temperatur dort bestimmt, wann der 
L�fter ausgeschaltet wird.

M�glicherweise unterst�tzt Ihr Ger�t nicht 7 verschiedene L�fterstufen. Ein Nutzer 
berichtete, dass die Geschwindigkeiten 1/2, 2/4/5 und 6/7 jeweils gleich sind. 

Auf T40/R50 Modellen wurde sogar von weniger L�fterstufen (nur 1/2/3) berichtet. 



-------------------------------
 Temperatur-Sensoren:
-------------------------------

Der erste Temperaturwert ist wahrscheinlich die CPU. Die Bedeutung einiger 
anderer Sensoren ist derzeit unbekannt. Sollte jemand sein Thinkpad �ffnen wollen 
und mit K�hlspray mehr herausfinden, m�ge er davon berichten.

Im Folgenden werden die bisherigen Erkenntnisse �ber die Sensoren bekanntgegeben 
(basierend auf http://www.thinkwiki.org/wiki/Talk:Problem_with_fan_noise): 

  CPU: Definitiv die CPU

  APS: Temperatursensor zwischen CPU und PCMCIA Slots (unter
       der linken Alt Taste beim T43 2668)

  PCM: unter dem PCMCIA Einschub (im Geh�use vorne/links)

  GPU: Graphikprozessor

  BAT: Batterie (innerhalb der T43 Batterie links/vorne)

  BAT: Batterie (innerhalb der T43 Batterie rechts/hinten)

  BUS: Zwischen Northbridge Chip und DRAM (unter den Tasten R/T/Z)

  PCI: Southbridge Chip unter dem Touchpad (reagiert auf WLAN-Gebrauch)

  PWR: Energieversorgung (unter dem Access-IBM Knopf, erhitzt sich 
       wenn die Batterie geladen wird)



-------------------------------
 EC Port/Andere Programme:
-------------------------------

Probleme zeigten sich beim Betrieb mit anderen, �hnlichen Programmen. Haupts�chlich
mit Notebook Hardware Control. Die Probleme scheinen auf Konflikten beim Auslesen der 
Embedded Controller Register. Bisher ist die beste L�sung daf�r, diese Programme 
auszuschalten.



-------------------------------
  Versionen:
-------------------------------

V0.10 - 2005-11-27
 - erste Version


V0.11 - 2005-11-28
 - Anzeige der Temp. mit den bekannten Bedeutungen
 - Anzeige des L�fterstatus bei �nderungen in hex
 - Status im minimierten Fenstertitel
 - Ver�nderung des Kontrolltones m�glich
 - Ver�nderungen im GUI

V0.12 - 2005-11-29
 - Anzeige der L�ftergeschwindigkeit in RPM
 - M�glichkeit, im Smart-Mode die L�fterkontrolle bei bestimmten Temperaturen 
   ans Bios zu �bergeben
   
V0.13 - 2005-11-29
 - Detaillierteres Log
 - Log-Datei auf 100 Zeilen limitiert
 - write logfile (fancontrol.log)


V0.14 - 2005-11-30
 - Taskbar-Icon (siehe fancontrol.ini)
 - M�glichkeit, im Smart-Mode zu starten

V0.15 - 2005-11-30
 - Bugfix: Auslesen der Icon-Levels aus der ini
 - minimiert starten
 - M�glichkeit, Sensoren zu ignorieren
 - Programmende nach konfigurierbarer Anzahl von Lesefehlern

V0.16 - 2005-12-04
 - Schnellere Reaktionszeit des Fensters
 - M�glichkeit, im Smart-Mode die Kontrolle vom BIOS zur�ckzuerhalten
 - Option, dass das Schlie�en des Fensters das Programm minimert

V0.17 - 2005-12-05
 - Bugfix: internal lockup




-------------------------------
 Ideen:
-------------------------------

- Betrieb als Windows-Dienst
- Das pulsierende-L�fter-Problem beseitigen
- Verschiedene Schwellenwerte f�r GPU/CPU



-------------------------------
 Hall of Fame:
-------------------------------

Dank an

- Thinkerer aus dem www.thinkpads.com Forum 
  f�r die Hintergrundinformationen zu den 
  Temperatursensoren

- Sebume aus dem www.thinkpad-forum.de Forum
  f�r die deutsche �bersetzung des README Textes
  

- mANoLo27 aus dem www.thinkpad-forum.de Forum
  f�r die deutschen Kommentare im der fancontrol.ini
  Datei
  