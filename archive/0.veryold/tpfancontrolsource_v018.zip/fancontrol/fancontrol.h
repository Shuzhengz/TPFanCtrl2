
// --------------------------------------------------------------
//
//  Thinkpad Fan Control
//
// --------------------------------------------------------------
//
//	This program and source code is in the public domain.
//
//	The author claims no copyright, copyleft, license or
//	whatsoever for the program itself (with exception of
//	WinIO driver).  You may use, reuse or distribute it's 
//	binaries or source code in any desired way or form,  
//	Useage of binaries or source shall be entirely and 
//	without exception at your own risk. 
// 
// --------------------------------------------------------------

#ifndef FANCONTROL_H
#define FANCONTROL_H

#pragma once

#include <windows.h>
#include <commctrl.h>

#include "winstuff.h"

#include <stdio.h>
#include <stdlib.h>


#define FANCONTROLVERSION "0.18"

#define WM__DISMISSDLG WM_USER+5
#define WM__GETDATA WM_USER+6
#define WM__NEWDATA WM_USER+7
#define WM__TASKBAR WM_USER+8


#define setzero(adr, size)		memset((void*)(adr), (char)0x00, (size))
#define ARRAYMAX(tab) (sizeof(tab)/sizeof((tab)[0]))
#define NULLSTRUCT	{ 0, }


extern char lasterrorstring[], 
			logbuf[];
extern int verbosity;




class FANCONTROL {

	protected:
		HWND hwndDialog;

		struct FCSTATE {

			char FanCtrl,
				 FanSpeedLo,
				 FanSpeedHi;

			char Sensors[12];
			int  SensorAddr[12];
			const char *SensorName[12];


		} State;

		struct SMARTENTRY {
				int temp, fan;
		} SmartLevels[32];


		int IconLevels[3];	// temp levels for coloring the icon
		int CurrentIcon;


		int Cycle; 
		int ActiveMode, 
			FinalSeen;
		int CurrentMode, 
			PreviousMode;
		int MaxTemp;
		int FanBeepFreq, FanBeepDura;
		int MinimizeToSysTray,
			MinimizeOnClose,
			StartMinimized;
		int ReadErrorCount;
		int MaxReadErrors;
		char IgnoreSensors[256];
		HANDLE hThread;
		BOOL Closing;
		MUTEXSEM EcAccess;

		char Title[128];
		char Title2[128];
		char LastTitle[128];
		char LastTooltip[128];
		char CurrentStatus[256];

		TASKBARICON *pTaskbarIcon;


		// dialog.cpp
		int CurrentModeFromDialog();
		void ModeToDialog(int mode);
		ULONG DlgProc(HWND hwnd, ULONG msg, WPARAM mp1, LPARAM mp2);
		static ULONG CALLBACK BaseDlgProc(HWND hwnd, ULONG msg, WPARAM mp1, LPARAM mp2);

		static int _stdcall FANCONTROL_Thread(ULONG parm) \
                        { return ((FANCONTROL *)parm)->WorkThread(); }


		int WorkThread();


		// fancontrol.cpp
		int ReadEcStatus(FCSTATE *pfcstate);
		int ReadEcRaw(FCSTATE *pfcstate);
		int HandleData();
		int SmartControl();
		int SetFan(const char *source, int level, BOOL final= false);


		// misc.cpp
		int ReadConfig(const char *filename);
		void Trace(const char *text);
		BOOL IsMinimized(void);
		void CurrentDateTimeLocalized(char *result, int resultsize);
		HANDLE CreateThread(int (_stdcall *fnct)(ULONG), ULONG p);


		// portio.cpp
		int ReadByteFromEC(int offset, char *pdata);
		int WriteByteToEC(int offset, char data);

	public:

		FANCONTROL(HINSTANCE );
		~FANCONTROL();

		void Test(void);


		int ProcessDialog();



};

#endif // FANCONTROL_H