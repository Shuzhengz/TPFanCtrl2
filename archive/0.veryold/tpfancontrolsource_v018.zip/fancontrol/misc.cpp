
// --------------------------------------------------------------
//
//  Thinkpad Fan Control
//
// --------------------------------------------------------------
//
//	This program and source code is in the public domain.
//
//	The author claims no copyright, copyleft, license or
//	whatsoever for the program itself (with exception of
//	WinIO driver).  You may use, reuse or distribute it's 
//	binaries or source code in any desired way or form,  
//	Useage of binaries or source shall be entirely and 
//	without exception at your own risk. 
// 
// --------------------------------------------------------------

#include "fancontrol.h"





//-------------------------------------------------------------------------
//  read config file
//-------------------------------------------------------------------------
int
FANCONTROL::ReadConfig(const char *configfile)
{
	char buf[1024];
	int i, ok= false, lcnt= 0;


	//
	// read from file
	//
	FILE *f= fopen(configfile, "r");
	if (f) {
		while (!feof(f)) {
			strcpy(buf, "");
			fgets(buf, sizeof(buf), f);

			if (buf[0]=='/' || buf[0]=='#' || buf[0]==';')
				continue;

			if (strnicmp(buf, "active=", 7)==0) {
				this->ActiveMode= atoi(buf+7);
			}
			else
			if (strnicmp(buf, "cycle=", 6)==0) {
				this->Cycle= atoi(buf+6);
			}
			else
			if (strnicmp(buf, "level=", 6)==0) {
				sscanf(buf+6, "%d %d", &this->SmartLevels[lcnt].temp, &this->SmartLevels[lcnt].fan);
				lcnt++;
			}
			else
			if (strnicmp(buf, "fanbeep=", 8)==0) {
				sscanf(buf+8, "%d %d", &this->FanBeepFreq, &this->FanBeepDura);
			}
			else
			if (strnicmp(buf, "iconlevels=", 11)==0) {
				sscanf(buf+11, "%d %d %d", &this->IconLevels[0], &this->IconLevels[1], &this->IconLevels[2]);
			}
			else
			if (strnicmp(buf, "MinimizeToSysTray=", 18)==0) {
				this->MinimizeToSysTray= atoi(buf+18);
			}
			else
			if (strnicmp(buf, "StartMinimized=", 15)==0) {
				this->StartMinimized= atoi(buf+15);
			}
			else
			if (strnicmp(buf, "MinimizeOnClose=", 16)==0) {
				this->MinimizeOnClose= atoi(buf+16);
			}
			else
			if (strnicmp(buf, "MaxReadErrors=", 14)==0) {
				this->MaxReadErrors= atoi(buf+14);
			}
			else
			if (strnicmp(buf, "IgnoreSensors=", 14)==0) {
				char *p= buf+14, *p2= this->IgnoreSensors;

				while (*p) {	// copy excluding space and tab
					if (*p!=' ' && *p!='\t' && *p!='\r' && *p!='\n') 
						*p2++= *p;
					p++;
				}
				*p2= '\0';
			}
		}


		fclose(f);

		// end marker for smart levels array
		if (lcnt) {
			this->SmartLevels[lcnt].temp= -1;
			this->SmartLevels[lcnt].fan= 0x80;
		}

		ok= true;
	}


	//
	// display config
	//
	this->Trace("Current Config:");
	sprintf(buf, "  Active= %d, Cycle= %d, FanBeep= %d %d, MaxReadErrors= %d", 
					this->ActiveMode, this->Cycle,
					this->FanBeepFreq, this->FanBeepDura, this->MaxReadErrors);
	this->Trace(buf);
	sprintf(buf, "  IconLevels= %d %d %d, IgnoreSensors= %s", 
					this->IconLevels[0], this->IconLevels[1], this->IconLevels[2],
					this->IgnoreSensors);
	this->Trace(buf);

	strcpy(buf, "  Levels= ");
	for (i= 0; this->SmartLevels[i].temp!=-1; i++) {
		sprintf(buf+strlen(buf), "%s%d�C -> ",	
					i>0 ? ",  " : "",
					this->SmartLevels[i].temp);

		if (this->SmartLevels[i].fan!=0x80) 
			sprintf(buf+strlen(buf), "%d", this->SmartLevels[i].fan);
		else
			strcat(buf, "0x80");
	}
	this->Trace(buf);
	this->Trace("");

	return ok;
}



//-------------------------------------------------------------------------
//  localized time
//-------------------------------------------------------------------------
void
FANCONTROL::CurrentDateTimeLocalized(char *result, int resultsize)
{
	SYSTEMTIME s;
	::GetLocalTime(&s);

	char otfmt[64]= "HH:mm:ss", otime[64];
	char odfmt[128], odate[64];


	::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_STIMEFORMAT, otfmt, sizeof(otfmt));

	::GetTimeFormat(LOCALE_USER_DEFAULT, 0, &s, otfmt, otime, sizeof(otime));

	::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SSHORTDATE, odfmt, sizeof(odfmt));

	::GetDateFormat(LOCALE_USER_DEFAULT, 0,	&s, odfmt, odate, sizeof(odate));

	setzero(result, resultsize);
	strncpy(result, odate, resultsize-2);
	strcat(result, " ");
	strncat(result, otime, resultsize-strlen(result)-1);
}



//-------------------------------------------------------------------------
//  
//-------------------------------------------------------------------------
BOOL 
FANCONTROL::IsMinimized(void)
{
	WINDOWPLACEMENT wp= NULLSTRUCT;

	::GetWindowPlacement(this->hwndDialog, &wp);

	return wp.showCmd==SW_SHOWMINIMIZED;
}




//-------------------------------------------------------------------------
//  show trace output in lower window part
//-------------------------------------------------------------------------
void 
FANCONTROL::Trace(const char *text)
{
	char trace[8192]= "", datebuf[128]= "", line[256]= "";

	this->CurrentDateTimeLocalized(datebuf, sizeof(datebuf));

	::GetDlgItemText(this->hwndDialog, 9200, trace, sizeof(trace));

	if (strlen(text)) 
		sprintf(line, "[%s] %s\r\n", datebuf, text);	// probably acpi reading conflict
	else
		strcpy(line, "\r\n");

	strcat(trace, line);

	
	//
	// display 100 lines max
	//
	char *p= trace + strlen(trace);
	int linecount= 0;

	while (p>= trace) {

		if (*p=='\n') {
			linecount++;
			if (linecount>100)
				break;
		}

		p--;
	}


	// 
	// write logfile
	//
	FILE *flog= fopen("fancontrol.log", "ab");
	if (flog) {
		fwrite(line, strlen(line), 1, flog); 
		fclose(flog);
	}


	//
	// redisplay log and scroll to bottom
	//
	::SetDlgItemText(this->hwndDialog,9200, p+1);
	::SendDlgItemMessage(this->hwndDialog, 9200, EM_SETSEL, strlen(trace)-2, strlen(trace)-2);
	::SendDlgItemMessage(this->hwndDialog, 9200, EM_LINESCROLL, 0, 9999);
}




//-------------------------------------------------------------------------
//  create a thread
//-------------------------------------------------------------------------
HANDLE
FANCONTROL::CreateThread(int (_stdcall *fnct)(ULONG), ULONG p)
{
    LPTHREAD_START_ROUTINE thread= (LPTHREAD_START_ROUTINE)fnct;
    DWORD tid;
    HANDLE hThread;
    hThread= ::CreateThread(NULL, 8*4096, thread, (void*)p, 0, &tid);
    return hThread;
}